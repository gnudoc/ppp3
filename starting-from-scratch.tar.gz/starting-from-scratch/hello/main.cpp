#include "PPPheaders.h"

// --- Test for C++20 Concepts ---
template<integral T> // No need for std::
T add_only_integrals(T a, T b) {
    return a + b;
}

void test_concepts() {
    cout << "\n--- Testing C++20 Concepts ---\n";
    int i1 = 5, i2 = 10;
    cout << "Adding two ints: " << add_only_integrals(i1, i2) << endl;
    char c1 = 10, c2 = 20;
    cout << "Adding two chars: " << static_cast<int>(add_only_integrals(c1, c2)) << endl;
    cout << "Successfully called concept-constrained function with valid types. Concepts test PASSED.\n";
}


// --- Test for C++20 Span ---
void process_span(span<int> s) { // No need for std::
    cout << "Processing a span of size " << s.size() << ": ";
    for (int x : s) {
        cout << x << " ";
    }
    cout << endl;
}

void test_span() {
    cout << "\n--- Testing C++20 Span ---\n";
    int c_array[] = {10, 20, 30, 40};
    vector<int> vec = {50, 60, 70}; // No need for std::
    cout << "Calling process_span with a C-style array:\n";
    process_span(c_array);
    cout << "Calling process_span with a std::vector:\n";
    process_span(vec);
    cout << "Successfully passed different container types to a function accepting a span. Span test PASSED.\n";
}


// --- Test for C++20 Ranges ---
void print_vector(const string& label, const vector<int>& v) { // No need for std::
    cout << label;
    for (int x : v) {
        cout << x << " ";
    }
    cout << endl;
}

void test_ranges() {
    cout << "\n--- Testing C++20 Ranges ---\n";
    vector<int> numbers = {5, 2, 8, 1, 9, 4}; // No need for std::
    print_vector("Original: ", numbers);

    // Because of "using namespace std;", ranges algorithms are brought in.
    ranges::sort(numbers);
    print_vector("Sorted:   ", numbers);

    int value_to_find = 8;
    auto it = ranges::find(numbers, value_to_find);

    if (it != numbers.end()) {
        cout << "Found " << value_to_find << " in the sorted vector. Ranges test PASSED.\n";
    } else {
        cout << "Did not find " << value_to_find << ". Ranges test FAILED.\n";
    }
}


// --- Main Function ---
int main() {
    try {
        test_concepts();
        test_span();
        test_ranges();
        cout << "\n\nConclusion: Our toolchain successfully handles modern C++ features.\n";
    }
    catch (exception& e) { // No need for std::
        cerr << "Error: " << e.what() << endl;
        return 1;
    }
    catch (...) {
        cerr << "Unknown error" << endl;
        return 2;
    }
    return 0;
}

